# App Icon Setup

To set a custom app icon:

1. Place your icon file in this folder.
2. Name it `AppIcon.icns` (recommended) or `AppIcon.png`.
3. Rebuild and run the app.

Example path:

`Sources/LongAutoTyper/Resources/AppIcon.icns`
